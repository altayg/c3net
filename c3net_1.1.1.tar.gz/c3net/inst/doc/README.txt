If you have the 

c3net_1.1.0.tar.gz

then for linux in command line, type the following to install c3net package

 $  R CMD INSTALL c3net

Once this is installed, you will only type in R the following each time you use c3net.

 >  library(c3net)



